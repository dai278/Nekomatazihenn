#pragma once

#include "DrawObject/DrawObject.h"

class GameOverCharacter :public DrawObject
{
public:
	void Init()override;
};