#include "GameOverCharacter/GameOverCharacter.h"
#include "AppDef.h"

void GameOverCharacter::Init() {
	mTexture.Load("Images/2dAction/GameOver.png");
	DrawObject::Init();
	mSprite.SetSize(1300.0f, 300.0f);
	mPosition = Vector2f(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2+100.f);
}