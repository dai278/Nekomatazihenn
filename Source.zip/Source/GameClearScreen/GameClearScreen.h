#pragma once

#include "DrawObject/DrawObject.h"

class GameClearScreen :public DrawObject
{
public:
	void Init()override;
};