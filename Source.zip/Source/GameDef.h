﻿#pragma once

//方向を示す定数
enum class Direction {
	Front,
	Right,
	Back,
	Left,
};

//インゲームの衝突グループを示す定数
enum class CollisionGroup {
	Player,
	StageSelectPlayer,
	StageObject,
	Weapon,
	Enemy,
	Goal,
	LastGoal,
	MoveMapObject,
	EnemyBullet,
	EnemyWeapon,
};

enum class GrapplinghookSta {
	Select,
	hanging,
};

//シーン種別
enum class SceneType {
	None = -1,

	Title,
	InGame,
	GameOver,
	GameClear,
	StageSelect,
};