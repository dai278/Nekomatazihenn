#include "ContinueObject/ContineuObject.h"
#include "AppDef.h"

void ContinueObject::Init() {
	mTexture.Load("Images/2dAction/continue.png");
	DrawObject::Init();
	mSprite.SetSize(400.0f, 150.0f);
	mPosition = Vector2f(630.f, (WINDOW_HEIGHT / 4) * 1);
	mSprite.SetPriority(150.f);
}