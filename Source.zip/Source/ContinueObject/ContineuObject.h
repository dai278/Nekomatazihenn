#include "DrawObject/DrawObject.h"

class ContinueObject :public DrawObject
{
public:
	void Init()override;
};