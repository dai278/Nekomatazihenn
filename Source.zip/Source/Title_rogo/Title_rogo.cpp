#include "Title_rogo/Title_rogo.h"
#include "Fwk/Framework.h"

//�E�B���h�E�T�C�Y�̒萔���g���̂�include
#include "AppDef.h"


const float FirstPosition_y = -300.0f;
const float HalfPosition_y = -310.0f;

void Title_Rogo::Init() {

	//�e�N�X�`���̓ǂݍ���
	mTexture.Load("Images/2dAction/Title_rogo.png");
	//�X�v���C�g�̏�����
	mSprite.Init();
	mSprite.SetTexture(mTexture);
	mPosition.x = WINDOW_WIDTH / 2.0f;
	mPosition.y = FirstPosition_y;
	mSprite.SetPosition(mPosition);
	mSprite.SetSize(1000.0f,589.35f);
	mSprite.SetPriority(150);
	mSprite.SetVisible(true);
	mtitlerogoscene = TitleRogoScene::FirstDown;
}

//��Еt��
void Title_Rogo::Term()
{
	mSprite.Term();
	mTexture.Unload();
}

//�X�V
void Title_Rogo::Update()
{
	mTimer += 3.0f* Time_I->GetDeltaTime();

	switch (mtitlerogoscene)
	{
	case Title_Rogo::TitleRogoScene::FirstDown:
		_updateFirstDown();
		break;
	case Title_Rogo::TitleRogoScene::LastDown:
		_updateLastDown();
		break;

	}
	mSprite.SetPosition(mPosition);
	mSprite.Update();
}

//�`��
void Title_Rogo::Render() {
	mSprite.Draw();
}

void Title_Rogo::_updateFirstDown() {
	mPosition.y = mPosition.y + (-(mTimer * mTimer) + (2 * mTimer));
	if (mPosition.y <= HalfPosition_y) {
		mtitlerogoscene = TitleRogoScene::LastDown;
		mTimer = 0.f;
	}
}

void Title_Rogo::_updateLastDown() {
	mPosition.y = mPosition.y + -(-(mTimer * mTimer) + (2 * mTimer));
	if (mPosition.y >= FirstPosition_y) {
		mtitlerogoscene = TitleRogoScene::FirstDown;
		mTimer = 0.f;
	}
}


