#pragma once

#include "DrawObject/DrawObject.h"

class Sign :public DrawObject
{
public:
	void Init()override;
};