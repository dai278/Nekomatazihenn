#pragma once

#include "DrawObject/DrawObject.h"
//Sprite��Texture�AAnimation���g���ׂ̃w�b�_�t�@�C��
#include "Fwk/Graphics.h"

class  StageDecided :public DrawObject
{
public:
	void Init()override;
	void Update()override;
	void Render()override;
	void Term()override;

	void SetIsActive(bool isactive);

private:
	bool mIsActive;
};