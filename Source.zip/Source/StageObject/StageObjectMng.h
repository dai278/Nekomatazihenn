#pragma once

#include "StageObject/StageObject_1.h"
#include "StageObject/StageObject_2.h"
#include "StageObject/StageObject_3.h"
#include "StageObject/StageObject_4.h"

class StageObjectMng
{
public:
	void Init();
	void Update();
	void Render();
	void Term();

	int GetStageNumberPieces()const;

	StageObject_1* GetStageObject_1();
	StageObject_2* GetStageObject_2();
	StageObject_3* GetStageObject_3();
	StageObject_4* GetStageObject_4();
private:
	StageObject_1 mStageObject_1;
	StageObject_2 mStageObject_2;
	StageObject_3 mStageObject_3;
	StageObject_4 mStageObject_4;

	const int mStageNum = 4;
};