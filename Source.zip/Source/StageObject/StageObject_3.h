#pragma once

#include "StageObject/StageObject.h"

class StageObject_3 :public StageObject
{
public:
	void Init()override;
};
