#pragma once

#include "StageObject/StageObject.h"

class StageObject_4 :public StageObject
{
public:
	void Init()override;
};
