#pragma once

#include "StageObject/StageObject.h"

class StageObject_2 :public StageObject
{
public:
	void Init()override;
};
