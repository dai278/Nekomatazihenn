#include "StageObject/StageObjectMng.h"

//������
void StageObjectMng::Init() {
	mStageObject_1.Init();
	mStageObject_2.Init();
	mStageObject_3.Init();
	mStageObject_4.Init();
}

//�X�V
void StageObjectMng::Update() {
	mStageObject_1.Update();
	mStageObject_2.Update();
	mStageObject_3.Update();
	mStageObject_4.Update();
}

//�`��
void StageObjectMng::Render() {
	mStageObject_1.Render();
	mStageObject_2.Render();
	mStageObject_3.Render();
	mStageObject_4.Render();
}

//��Еt��
void StageObjectMng::Term() {
	mStageObject_1.Term();
	mStageObject_2.Term();
	mStageObject_3.Term();
	mStageObject_4.Term();
}

StageObject_1* StageObjectMng::GetStageObject_1() {
	return &mStageObject_1;
}


StageObject_2* StageObjectMng::GetStageObject_2() {
	return &mStageObject_2;
}

StageObject_3* StageObjectMng::GetStageObject_3() {
	return &mStageObject_3;
}

StageObject_4* StageObjectMng::GetStageObject_4() {
	return &mStageObject_4;
}

int StageObjectMng::GetStageNumberPieces()const {
	return mStageNum;
}