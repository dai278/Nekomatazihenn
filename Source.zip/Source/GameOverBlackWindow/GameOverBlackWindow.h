#include "DrawObject/DrawObject.h"

class GameOverBlackWindow :public DrawObject
{
public:
	void Init()override;
};