#include "GameOverBlackWindow/GameOverBlackWindow.h"
#include "AppDef.h"

void GameOverBlackWindow::Init() {
	mTexture.Load("Images/2dAction/Black.png");
	DrawObject::Init();
	mSprite.SetSize(WINDOW_WIDTH, WINDOW_HEIGHT);
	mPosition=Vector2f(WINDOW_WIDTH/2, WINDOW_HEIGHT/2 );
}