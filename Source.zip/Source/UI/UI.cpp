#include "UI/UI.h"

void UI::Init() {
	//������
	mSprite.Init();
	//�`��
	mSprite.SetVisible(true);
	//UI���C���[�ɕ`�悷��
	mSprite.SetRenderLayer("UI");
}

void UI::Update() {
	mSprite.Update();
}

void UI::Render() {
	mSprite.Draw();
}

void UI::Term() {
	mTexture.Unload();
	mSprite.Term();
}

void UI::SetActive(bool active) {
	mSprite.SetVisible(active);
}