#pragma once

//Sprite,Texture���g���̂�include
#include "Fwk/Graphics.h"

//UI���N���X
class UI
{
public:
	virtual void Init();
	virtual void Update();
	virtual void Term();
	virtual void Render();

	void SetActive(bool active);
protected:
	Texture mTexture;
	Sprite mSprite;

};