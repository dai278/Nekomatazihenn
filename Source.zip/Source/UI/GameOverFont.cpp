#pragma once
#include "GameOverFont.h"
#include "AppDef.h"
#include "Fwk/Framework.h"

void GameOverFont::Init() {
	mTexture.Load("Images/2dAction/GameOver.png");

	//�Q�[���I�[�o�[�X�v���C�g�����ݒ�
	mSprite.Init();
	mSprite.SetTexture(mTexture);
	mSprite.SetSize(1300.0f, 300.0f);
	mSprite.SetPosition(WINDOW_WIDTH / 2.0f, -WINDOW_HEIGHT / 2.0f );
	mSprite.SetAlpha(0.0f);
	mSprite.SetVisible(true);
	mSprite.SetPriority(1500);
	mGameOverPrausAlpha = 0.0f;

	mSprite.SetRenderLayer("UI");
	mIsAddAlpha = false;
}

void GameOverFont::Update() {
	if (!mIsAddAlpha) {
		return;
	}
	mGameOverPrausAlpha += 0.7 * Time_I->GetDeltaTime();
	mSprite.SetAlpha(mGameOverPrausAlpha);
	if (mGameOverPrausAlpha >= 1.0f) {
		mGameOverPrausAlpha = 1.0f;
	}
	mSprite.SetPosition(WINDOW_WIDTH / 2.0f, -WINDOW_HEIGHT / 2.0f + 100.f);

}

void  GameOverFont::SetIsAddAlpha(bool IsAddAlpha) {
	this->mIsAddAlpha = IsAddAlpha;
}
