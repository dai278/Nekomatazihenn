#include "BossHpGauge.h"
#include "AppDef.h"
#include "GameObjectMng/GameObjectMng.h"

void BossHpGauge::Init() {
	mTexture.Load("Images/2dAction/BossHp.png");
	UI::Init();
	mSprite.SetTexture(mTexture);
	mSprite.SetPriority(850);
	mSprite.SetPosition(Vector2f(1615, -100));
	mSprite.SetSize(800.f, 80.f);
	mSprite.SetPivot(Pivot::Left);
	mSprite.SetRotation(180.f);
	mIsActive = false;
	mScalingHp = 0.f;
}

void BossHpGauge::Update() {
	if (!mIsActive) {
		return;
	}

	mScalingHp += 0.3 * Time_I->GetDeltaTime();
	float ScalingBossHp = GetEnemyMng()->GetBossHp();
	if (mScalingHp >= ScalingBossHp) {
		mScalingHp = ScalingBossHp;
	}

	if (mScalingHp > 1.0f) {
		mScalingHp = 1.0f;
	}
	if (mScalingHp < 0.0f) {
		mScalingHp = 0.0f;
	}

	//�X�v���C�g���X�P�[�����O
	mSprite.SetScale(mScalingHp, 1.0f);
	//�X�P�[�����O�Ƀe�N�X�`�����W�̕������킹��
	mSprite.SetTexCoord(0.0f, 0.0f, mScalingHp, 1.0f);


	UI::Update();
}

void BossHpGauge::Render() {
	if (!mIsActive) {
		return;
	}
	UI::Render();
}

void BossHpGauge::SetIsActive(bool isactive) {
	mIsActive = isactive;
}
