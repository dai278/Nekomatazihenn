#include "UI/DeathScreen.h"

#include "AppDef.h"
#include "GameObjectMng/GameObjectMng.h"

void DeathScreen::Init() {
	mTexture.Load("Images/2dAction/Black.png");

	//������ʂ̃X�v���C�g�����ݒ�
	UI::Init();
	mSprite.SetTexture(mTexture);
	mSprite.SetSize(1920.0f, 1080.0f);
	mSprite.SetAlpha(0.0f);
	mSprite.SetPriority(1000);
	mBlackPrausAlpha = 0.0f;
	mIsAddAlphaFinish = false;

	mDeathScreenDoing = DeathScreenDoing::WaitFlag;

}

void DeathScreen::Update() {
	switch (mDeathScreenDoing)
	{
	case DeathScreen::DeathScreenDoing::WaitFlag:
		mBlackPrausAlpha = 0.0f;
		mSprite.SetAlpha(mBlackPrausAlpha);
		if (GetPlayer()->IsDied() == true) {
			mDeathScreenDoing = DeathScreenDoing::BlackScreen;
		}
		break;

	case DeathScreen::DeathScreenDoing::BlackScreen:
		mBlackPrausAlpha += 0.7 * Time_I->GetDeltaTime();
		mSprite.SetAlpha(mBlackPrausAlpha);
		if (mBlackPrausAlpha >= 1.0f) {
			mBlackPrausAlpha = 1.0f;
			mIsAddAlphaFinish = true;
		}
		break;

	case DeathScreenDoing::Translucent:
		mBlackPrausAlpha = 0.5f;
		mSprite.SetAlpha(mBlackPrausAlpha);
	}
	
	mSprite.SetPosition(WINDOW_WIDTH / 2.0f, -WINDOW_HEIGHT / 2.0f);
}


bool DeathScreen::IsAddAlphaFinish()const {
	return mIsAddAlphaFinish;
}

void DeathScreen::SetTranslucent(bool translucent) {
	if (translucent) {
		mDeathScreenDoing = DeathScreenDoing::Translucent;
	}
	else
	{
		mDeathScreenDoing = DeathScreenDoing::WaitFlag;
	}
}
