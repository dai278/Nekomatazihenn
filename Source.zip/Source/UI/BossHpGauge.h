#pragma once

#include "UI/UI.h"

class BossHpGauge :public UI
{
public:
	void Init()override;
	void Update()override;
	void Render()override;
	void SetIsActive(bool isactive);
private:
	bool mIsActive;
	float mScalingHp;
};