#include "MoveStageSelectObject/MoveStageSelectObject.h"
#include "AppDef.h"

void MoveStageSelectObject::Init() {
	mTexture.Load("Images/2dAction/StageSelect.png");
	DrawObject::Init();
	mSprite.SetSize(400.0f, 150.0f);
	mPosition = Vector2f(1330.f, (WINDOW_HEIGHT / 4) * 1);
	mSprite.SetPriority(150.f);
}