#include "DrawObject/DrawObject.h"

class MoveStageSelectObject :public DrawObject
{
public:
	void Init()override;
};