#include "GameOverArrow/GameOverArrow.h"
#include "AppDef.h"

void GameOverArrow::Init() {
	mTexture.Load("Images/2dAction/GameOverArrow.png");
	DrawObject::Init();
	mSprite.SetSize(200.0f, 150.0f);
	mPosition = Vector2f(300.f, (WINDOW_HEIGHT / 4) * 1);
	mSprite.SetPriority(200.f);

	mIndex = 0;
}

void GameOverArrow::Update() {
	if (mIndex == 0) {
		mPosition = Vector2f(300.f, (WINDOW_HEIGHT / 4) * 1);
	}
	else if (mIndex == 1) {
		mPosition = Vector2f(1000.f, (WINDOW_HEIGHT / 4) * 1);
	}

	DrawObject::Update();

}


void GameOverArrow::SetIndex(int index) {
	this->mIndex = index;
}