#include "InugamiIcon/InugamiIcon.h"

void InugamiIcon::Init() {
	mTexture.Load("Images/2dAction/Inugami_Icon.png");
	UI::Init();
	mSprite.SetTexture(mTexture);
	mSprite.SetPriority(900);
	mSprite.SetPosition(Vector2f(1600.f, -100.f));
	mSprite.SetSize(200.f, 200.f);
	mSprite.SetPivot(Pivot::Left);
	mIsActive = false;
}

void InugamiIcon::Update() {
	if (!mIsActive) {
		return;
	}

	UI::Update();
}

void InugamiIcon::Render() {
	if (!mIsActive) {
		return;
	}
	UI::Render();
}

void InugamiIcon::SetIsActive(bool isactive) {
	mIsActive = isactive;
}
