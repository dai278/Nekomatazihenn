#pragma once
#include "UI/UI.h"

class InugamiIcon :public UI
{
public:
	void Init()override;
	void Update()override;
	void Render()override;
	void SetIsActive(bool isactive);
private:
	float mIsActive;

};