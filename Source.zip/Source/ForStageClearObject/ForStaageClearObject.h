#include "DrawObject/DrawObject.h"

class ForStageClearObject :public DrawObject
{
public:
	void Init() override;
	void Render() override;
	void Update() override;
	//�A�N�e�B�u���Z�b�g
	void SetIsActive(bool isactive);
private:
	bool mIsActive;

};