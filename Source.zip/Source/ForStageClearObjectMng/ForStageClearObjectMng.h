#pragma once

#include "ForStageClearObject/ForStaageClearObject.h"
class ForStageClearObjectMng
{
public:
	void Init();
	void Update();
	void Render();
	void Term();

private:
	ForStageClearObject mForStageClearObject[3];

};