#include "GameOverObjectMng/GameOverObjectMng.h"
#include "GameOverBlackWindow/GameOverBlackWindow.h"
#include "GameOverCharacter/GameOverCharacter.h"
#include "MoveStageSelectObject/MoveStageSelectObject.h"
#include "ContinueObject/ContineuObject.h"
#include "GameOverArrow/GameOverArrow.h"

GameOverBlackWindow mGameOverBlackWindow;
GameOverCharacter mGameOverCharter;
MoveStageSelectObject mMoveStageSelectObject;
ContinueObject mContinueObject;
GameOverArrow mGameOverArrow;
//������
void GameOverObjectInit() {
	mGameOverBlackWindow.Init();
	mGameOverCharter.Init();
	mMoveStageSelectObject.Init();
	mContinueObject.Init();
	mGameOverArrow.Init();
}


//�X�V
void GameOverObjectUpdate() {
	mGameOverBlackWindow.Update();
	mGameOverCharter.Update();
	mMoveStageSelectObject.Update();
	mContinueObject.Update();
	mGameOverArrow.Update();
}

//�`��
void GameOverObjectRender() {
	mGameOverBlackWindow.Render();
	mGameOverCharter.Render();
	mMoveStageSelectObject.Render();
	mContinueObject.Render();
	mGameOverArrow.Render();
}

//��Еt��
void GameOverObjectTerm() {
	mGameOverBlackWindow.Term();
	mGameOverCharter.Term();
	mMoveStageSelectObject.Term();
	mContinueObject.Term();
	mGameOverArrow.Term();
}


GameOverArrow* GetGameOverArrow() {
	return &mGameOverArrow;
}
