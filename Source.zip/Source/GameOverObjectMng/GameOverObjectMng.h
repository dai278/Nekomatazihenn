#pragma once
#include "GameOverArrow/GameOverArrow.h"

void GameOverObjectInit();

void GameOverObjectUpdate();

void GameOverObjectRender();

void GameOverObjectTerm();


GameOverArrow* GetGameOverArrow();