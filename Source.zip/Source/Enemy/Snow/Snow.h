#pragma once

#include "Enemy/Enemy.h"
#include "GameDef.h"



class Snow : public Enemy
{
public:
	//���݂̏�Ԃ������񋓌^
	enum class Status
	{
		Moving,
		Throw,
	};
	//������
	void Init();
	//�X�V
	void Update();
	void Term();

	void _updateMoving();
	void _updateThrow();
	void _initAnimation();
	void OnCreated() override;

private:
	float mTimer;
	Status mStatus;
	float Snowballcooltime;
	Direction mDirection;
	Vector2f vDirection;
	Vector2f vCheckPos;
	float speed;
	float CollisionWidth; // �Փ˔���T�C�Y
	float CollisionHeight;
};