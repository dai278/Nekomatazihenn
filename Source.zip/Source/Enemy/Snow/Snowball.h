#pragma once

#include "BulletMng/EnemyBullet.h"

class Snowball : public EnemyBullet
{
public:
	void Init() override;
	void Update() override;
	void collision(Vector2f vMove);
private:
	void OnHit(const CollisionEvent& collisionEvent);
};