#pragma once

#include "BulletMng/EnemyBullet.h"

class InugamiBullet : public EnemyBullet
{
public:
	void Init() override;
	void Update() override;
	void Render() override;
	void Term() override;
	void collision(Vector2f vMove);
	void SpriteSetRotation(float rotetion);

private:
	void OnHit(const CollisionEvent& collisionEvent);

	float mAngle;
};