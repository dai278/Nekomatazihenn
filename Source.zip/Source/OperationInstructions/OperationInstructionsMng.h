#include "OperationInstructions/OperationInstructions.h"

class OperationInstructionsMng
{
public:
	void Init();
	void Update();
	void Render();
	void Term();

	OperationInstruction* GetOperationInstructions(int Num);
private:

	OperationInstruction mOperationInstructions[3];
};