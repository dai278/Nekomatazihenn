#include "OperationInstructions/OperationInstructionsMng.h"

void OperationInstructionsMng::Init() {
	mOperationInstructions[0].SetTexture("Images/2dAction/OperationInstructions.png");
	mOperationInstructions[0].Init();
	mOperationInstructions[1].SetTexture("Images/2dAction/OperationInstructions_2.png");
	mOperationInstructions[1].Init();
	mOperationInstructions[2].SetTexture("Images/2dAction/OperationInstructions_3.png");
	mOperationInstructions[2].Init();

}

void OperationInstructionsMng::Update() {
	for (int i = 0; i < 3; ++i) {
		mOperationInstructions[i].Update();
	}
}

void OperationInstructionsMng::Render() {
	for (int i = 0; i < 3; ++i) {
		mOperationInstructions[i].Render();
	}
}

void OperationInstructionsMng::Term() {
	for (int i = 0; i < 3; ++i) {
		mOperationInstructions[i].Term();
	}
}

OperationInstruction* OperationInstructionsMng::GetOperationInstructions(int Num) {
	return &mOperationInstructions[Num];
}