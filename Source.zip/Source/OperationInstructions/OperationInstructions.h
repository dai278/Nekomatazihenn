#include "UI/UI.h"

class OperationInstruction :public UI
{
public:
	void Init()override;
	void SetTexture(string name);
};